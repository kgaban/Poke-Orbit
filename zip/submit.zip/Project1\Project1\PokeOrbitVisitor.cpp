/**
* \file PokeOrbitVisitor.cpp
*
* \author Marc VandenBerg
*
* A base class for visitors in our PokeOrbit App
*/

#include "stdafx.h"
#include "PokeOrbitVisitor.h"

/// Constructor
CPokeOrbitVisitor::CPokeOrbitVisitor()
{
}

/// Destructor
CPokeOrbitVisitor::~CPokeOrbitVisitor()
{
}
